

Prototype:

10 minutes

5 pages - demonstration


1-  slide a presentantion
2 - slide a bout librarty
2 - slide a bout project
2 - slide a bout feature what we will demonstrate

3 minutes to demonstration 6 screens
- 3d panorama - upload a image

1- 360 panorama three js 
2- folder or file
3- Filebrowser
4- Flilebrowser with chonsenfile
5- loading 60%
6- PopupVideo

2 slides code end the end.
1 slide to explain why we did it

TO DO
1- Logo (three, hand)
2- Code(Artem)
3- Icons( upload,file,folder)
4- Presentation (Júlio)
5- Spinner (gif)
6- Implements 360 visual for Video(art)
7- Uploading images, gif, video
8- Make own 360
9- Add filter